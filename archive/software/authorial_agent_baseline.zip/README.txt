Run: pip install openpyxl
python -m unittest discover -v
python ingest.py Authorial_Voice_Ledger_v0.4.xlsx baseline.sqlite
Imported rules are candidates only; later conversation results are not yet consolidated.
